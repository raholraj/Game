# GameGuardian — Silent Parental Control

> Invisible game time limiter for tech-savvy kids.

---

## How to Get the APK (GitHub Actions)

1. Create a **new private GitHub repository**
2. Upload / push the contents of this ZIP
3. Go to **Actions** tab → build starts automatically
4. After ~10 minutes: **Actions → latest run → Artifacts → GameGuardian-debug** → download the ZIP → extract `app-debug.apk`

> Second build onwards takes ~3 min (Gradle cache kicks in).

---

## Install on Phone

1. On the target phone: **Settings → Security → Unknown Sources → Allow** (or "Install unknown apps" for your file manager)
2. Transfer the APK to the phone (USB / Google Drive / Telegram)
3. Tap to install

---

## One-Time Parent Setup (≈2 minutes)

| Step | What to do |
|------|-----------|
| 1 | Open **"Core System Service"** app |
| 2 | Tap **Step 1** → find **"Core System"** in Accessibility list → toggle ON |
| 3 | Tap **Step 2** → confirm battery exemption |
| 4 | Tap **Step 3** → activate Device Admin |
| 5 | Tap **"Setup Complete"** → icon disappears |

> **MIUI / Xiaomi / Realme phones:** Also go to Security → Autostart and enable "Core System Service" so the OS doesn't aggressively kill it.

---

## Re-opening the Settings Screen

Dial **`*#1234#`** in the phone app → setup screen re-appears.

If this doesn't work on your ROM:
```
adb shell pm enable com.android.core.service/.MainActivity
```

---

## What the Child Experiences

```
Day 1
  Open Free Fire → plays normally for ~30 min → "crash"
  Reopen → plays 4–9 min → "crash"
  Reopen → plays 6 min → "crash"
  "Aaj game bahut glitch kar raha hai yaar"

Day 3
  "Yeh game hi kharab rehta hai"

Week 2
  "Free Fire mein bahut bugs hain lately"
```

---

## Technical Overview

| Mechanism | Detail |
|-----------|--------|
| Service type | `AccessibilityService` (not visible in BG apps list) |
| Session 1 / day | 27–34 min (random) |
| Sessions 2+ / day | 4–10 min (random) |
| Reset | Every midnight |
| Crash method | HOME press → 800 ms → `killBackgroundProcesses` |
| Uninstall protection | Device Admin |
| Icon | Hidden immediately after setup |
| Re-access | `*#1234#` in dialer |

---

## Adding More Games

Target packages are stored in SharedPreferences under key `target_packages`.
Default list:
- `com.dts.freefireth` — Free Fire
- `com.dts.freefiremax` — Free Fire MAX
- `com.pubg.imobile` — BGMI
- `com.tencent.ig` — PUBG Mobile

To add games, you can edit `GameWatcherService.kt` → `defaultTargets` before building.

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Game resumes instead of fresh-starting | `killBackgroundProcesses` partially blocked — the HOME+delay sequence still ensures child doesn't resume mid-game; try a second tap to reopen |
| Service stops on Xiaomi/OPPO | Enable Autostart + Battery exemption (Step 2 in setup) |
| Icon still visible after setup | Setup wasn't confirmed — open app again and tap "Setup Complete" |
| *#1234# doesn't work | Dial from default phone app (not third-party dialers); or use ADB |
