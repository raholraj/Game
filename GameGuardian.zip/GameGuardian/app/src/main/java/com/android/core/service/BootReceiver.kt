package com.android.core.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * BootReceiver — backup persistence after phone restart.
 *
 * The AccessibilityService automatically re-enables itself after
 * reboot if it was previously enabled. This receiver is a secondary
 * safety net that runs at high priority (999) early in the boot sequence.
 *
 * On modern Android (8+), we can't manually start AccessibilityService
 * from here — the system controls that. But we can log/init state
 * and do any housekeeping needed.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return

        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == "android.intent.action.LOCKED_BOOT_COMPLETED"
        ) {
            // AccessibilityService resumes on its own after boot.
            // Reset "crashing" state in prefs in case we were mid-crash
            // when the phone was restarted.
            context.getSharedPreferences(GameWatcherService.PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .remove("crashing")    // safety — not currently stored, just future-proof
                .apply()
        }
    }
}
