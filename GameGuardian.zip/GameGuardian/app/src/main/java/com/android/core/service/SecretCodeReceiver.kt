package com.android.core.service

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

/**
 * SecretCodeReceiver — listens for *#1234# dialed in the phone app.
 *
 * When triggered:
 * 1. Re-enables the MainActivity component (icon was hidden after setup)
 * 2. Launches MainActivity so parent can review/change settings
 *
 * Works on most Android versions. On some heavily skinned ROMs (MIUI 13+)
 * secret codes may behave differently — fallback is to use ADB:
 *   adb shell pm enable com.android.core.service/.MainActivity
 */
class SecretCodeReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        // Re-enable the launcher activity
        context.packageManager.setComponentEnabledSetting(
            ComponentName(context, MainActivity::class.java),
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP
        )

        // Open it immediately
        val launch = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        context.startActivity(launch)
    }
}
