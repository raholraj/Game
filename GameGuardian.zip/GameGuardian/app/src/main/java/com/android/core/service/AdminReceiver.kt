package com.android.core.service

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

/**
 * DeviceAdminReceiver — registers this app as a Device Administrator.
 *
 * Effect: the child cannot uninstall the app from Settings → Apps.
 * An error dialog will appear instead.
 *
 * The receiver is intentionally silent — no toasts, no logs.
 */
class AdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        // Device admin activated — silently proceed
    }

    override fun onDisabled(context: Context, intent: Intent) {
        // Device admin was removed (parent did it intentionally) — silently proceed
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        // Message shown if someone tries to remove Device Admin without first
        // going through the proper flow
        return "This component is required for core system services."
    }
}
