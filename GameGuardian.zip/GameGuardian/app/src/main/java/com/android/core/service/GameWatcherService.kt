package com.android.core.service

import android.accessibilityservice.AccessibilityService
import android.app.ActivityManager
import android.content.Context
import android.content.SharedPreferences
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*

/**
 * GameWatcherService — core of GameGuardian.
 *
 * Runs as an AccessibilityService (invisible in BG apps list).
 * Monitors foreground window changes to detect when target games
 * are launched, then applies randomised session time limits.
 *
 * Session logic:
 *   • Day's FIRST session  → 27–34 min (random)
 *   • Every next session   → 4–10 min  (random)
 *   • Midnight → full reset, first session limit restored
 *
 * Crash mechanism:
 *   1. performGlobalAction(HOME) → game goes BG
 *   2. 800 ms delay              → animation completes
 *   3. killBackgroundProcesses   → game process killed (ensures fresh restart)
 *   4. Result: child sees a crash, not a minimize
 */
class GameWatcherService : AccessibilityService() {

    // ── State ─────────────────────────────────────────────────────────────────

    private lateinit var prefs: SharedPreferences

    /** Package name of the game currently being timed, or null */
    private var activePackage: String? = null

    /** True while a session timer is running */
    private var inSession = false

    /**
     * True during the 2–3 second crash sequence.
     * During this window we ignore re-entrance events so we don't
     * accidentally start a new session or double-crash.
     */
    private var crashing = false

    /** Reference to the currently scheduled crash coroutine */
    private var crashJob: Job? = null

    /** Main-thread coroutine scope for all timing & crash actions */
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    // ── Default target packages (overridable via SharedPreferences) ────────────

    private val defaultTargets = setOf(
        "com.dts.freefireth",   // Free Fire
        "com.dts.freefiremax",  // Free Fire MAX
        "com.pubg.imobile",     // BGMI
        "com.tencent.ig"        // PUBG Mobile
    )

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onServiceConnected() {
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        // Seed target packages on first run
        if (!prefs.contains(KEY_TARGETS)) {
            prefs.edit().putStringSet(KEY_TARGETS, defaultTargets).apply()
        }
    }

    override fun onInterrupt() {
        scope.cancel()
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }

    // ── Accessibility events ──────────────────────────────────────────────────

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        // We only care about window-level foreground changes
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val pkg = event.packageName?.toString() ?: return
        val targets = getTargetPackages()

        when {
            pkg in targets -> onGameForeground(pkg)
            inSession && !crashing -> onGameBackground()
        }
    }

    // ── Game detected in foreground ───────────────────────────────────────────

    private fun onGameForeground(pkg: String) {
        // Ignore events that arrive during a crash sequence
        if (crashing) return

        // If already timing this exact game, ignore duplicate events
        if (inSession && activePackage == pkg) return

        // New session (game opened fresh, or a different target came foreground)
        startSession(pkg)
    }

    // ── Game left foreground (child went home / switched app) ─────────────────

    private fun onGameBackground() {
        inSession = false
        activePackage = null
        crashJob?.cancel()
        crashJob = null
        // Note: session_count is NOT decremented — the child already "used" that session slot
    }

    // ── Session management ────────────────────────────────────────────────────

    private fun startSession(pkg: String) {
        maybeResetDay()

        activePackage = pkg
        inSession = true

        val sessionIndex = prefs.getInt(KEY_SESSION_COUNT, 0)
        val limitMs = sessionLimitMs(sessionIndex)

        // Increment count immediately so if service dies, the count is saved
        prefs.edit().putInt(KEY_SESSION_COUNT, sessionIndex + 1).apply()

        // Cancel any stale job then schedule the crash
        crashJob?.cancel()
        crashJob = scope.launch {
            delay(limitMs)
            if (inSession && activePackage == pkg) {
                executeCrash(pkg)
            }
        }
    }

    /**
     * Returns the session time limit in milliseconds.
     * sessionIndex = 0 → first session of the day (27–34 min)
     * sessionIndex > 0 → subsequent sessions (4–10 min)
     */
    private fun sessionLimitMs(sessionIndex: Int): Long {
        return if (sessionIndex == 0) {
            val minutes = (27..34).random()
            minutes * 60_000L
        } else {
            val minutes = (4..10).random()
            minutes * 60_000L
        }
    }

    // ── Daily reset ───────────────────────────────────────────────────────────

    private fun maybeResetDay() {
        val today = datestamp()
        val saved = prefs.getString(KEY_LAST_DATE, "")
        if (saved != today) {
            prefs.edit()
                .putString(KEY_LAST_DATE, today)
                .putInt(KEY_SESSION_COUNT, 0)
                .apply()
        }
    }

    private fun datestamp(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    // ── Crash mechanism ───────────────────────────────────────────────────────

    /**
     * Steps:
     * 1. HOME button → game goes to BG (looks like minimise, not crash yet)
     * 2. 800 ms wait → game animation completes
     * 3. killBackgroundProcesses → process dead (next open = fresh start)
     * 4. 2 s grace period → if game still appears, press HOME again
     */
    private suspend fun executeCrash(pkg: String) {
        inSession = false
        crashing = true
        crashJob = null

        // Step 1 — simulate HOME press
        performGlobalAction(GLOBAL_ACTION_HOME)

        // Step 2 — wait for game to fully enter background
        delay(800)

        // Step 3 — kill the process so next launch is a cold start
        killGame(pkg)

        // Step 4 — hold crash flag for a grace period
        // If game somehow resurfaces during this window, onGameForeground
        // will see crashing=true and ignore it. After this delay we reset.
        delay(2_500)
        crashing = false
    }

    private fun killGame(pkg: String) {
        try {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            am.killBackgroundProcesses(pkg)
        } catch (_: Exception) {
            // Silently fail — double-check via re-entrance guard is backup
        }
    }

    // ── SharedPreferences helpers ─────────────────────────────────────────────

    private fun getTargetPackages(): Set<String> =
        prefs.getStringSet(KEY_TARGETS, defaultTargets) ?: defaultTargets

    // ── Constants ─────────────────────────────────────────────────────────────

    companion object {
        const val PREFS_NAME   = "gg_prefs"
        const val KEY_TARGETS  = "target_packages"
        const val KEY_SESSION_COUNT = "session_count"
        const val KEY_LAST_DATE     = "last_active_date"
    }
}
