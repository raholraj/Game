plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    // Rule 6: namespace MUST be declared for AGP 8+
    namespace = "com.android.core.service"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.android.core.service"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        debug {
            isDebuggable = true
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
        }
    }

    // Rule 4: explicitly declare BuildConfig to suppress warning→error
    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    // Coroutines for async crash timing
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
}
